/* test-matrix.c */

/**
 * Test program for matrix utilities
 *                                                           
 * Author:                                                                  
 */

/* includes of system headers */
#include <stdio.h>
#include <gmp.h> 

/* includes of project headers */

/* includes of local headers */
#include "mpq-vector.h"

/* Types and constant definitions */

#define VECTOR_SIZE  5

/* Global variables */

/* Functions */

int main(int argc, char ** argv)
{
  fprintf(stderr, "\n%s: This program does nothing yet!\n\n", argv[0]);
  return(0);
}
